https://stackoverflow.com/questions/60214194/error-in-reading-stock-data-datetimeproperties-object-has-no-attribute-week
https://datascienceparichay.com/article/most-frequent-value-in-a-pandas-column/
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.mode.html#:~:text=The%20mode%20of%20a%20set,It%20can%20be%20multiple%20values.&text=The%20axis%20to%20iterate%20over,get%20mode%20of%20each%20column
https://www.w3resource.com/python-exercises/pandas/datetime/pandas-datetime-exercise-8.php
https://stackoverflow.com/questions/26763344/convert-pandas-column-to-datetime
https://docs.python.org/3/library/datetime.html#strftime-and-strptime-behavior
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.to_datetime.html
https://stackoverflow.com/questions/50848454/pulling-most-frequent-combination-from-csv-columns