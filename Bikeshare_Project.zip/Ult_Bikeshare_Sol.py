import time
import numpy as np
import pandas as pd


CITY_DATA = { 'chicago': 'chicago.csv',
              'new york': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:
        city = input('Would you like to see data for Chicago, New york or Washington: \n').lower().strip()
        if city in CITY_DATA.keys():
            break
        else:
            print("sorry that was not clear could you choose a city again\n")
            continue


    while True:
        check_filter = input("Enter 'month', 'day' or 'both' to Specify a Filter Mode, You Can Type 'none' For No Filter. \n")
        # get user input for month (all, january, february, ... , june)
        if check_filter == 'both':
            while True:
                month = input('Which month? January, February, March, April, May or June? \n').lower().strip()
                if month in ['january', 'february', 'march', 'april', 'may', 'june']:
                    break
                else:
                    print("sorry that was not clear could you choose a month again\n")
                    continue
            while True:
                day = input('Which day? Saturday, Sunday, Monday, Tuesday, Wednesday, Thursday or Friday? \n').lower().strip()
                if day in ['saturday','sunday','monday','tuesday','wednesday','thursday','friday', 'none']:
                    break
                else:
                    print("sorry that was not clear could you choose a day again\n")
                    continue
            break

        elif check_filter == 'month':    
            while True:
                month = input('Which month? January, February, March, April, May or June? \n').lower().strip()
                if month in ['january', 'february', 'march', 'april', 'may', 'june']:
                    day = "none"
                    break
                else:
                    print("sorry that was not clear could you choose a month again\n")
                    continue
            break
        # get user input for day of week (all, monday, tuesday, ... sunday)
        elif check_filter == "day":
            while True:
                day = input('Which day? Saturday, Sunday, Monday, Tuesday, Wednesday, Thursday or Friday? \n').lower().strip()
                if day in ['saturday','sunday','monday','tuesday','wednesday','thursday','friday', 'none']:
                    month = "none"
                    break
                else:
                    print("sorry that was not clear could you choose a day again\n")
                    continue
            break
        elif check_filter == "none":
            month = day = "none"
            break
        else:
            print("sorry that was not clear could you choose a filter again\n")
            continue

    print('-'*40)
    print("City: {}\nMonth: {}\nDay: {}".format(city,month,day))
    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - pandas DataFrame containing city data filtered by month and day
    """

    # load data file into a dataframe
    if city in CITY_DATA.keys():
        df = pd.read_csv(CITY_DATA[city])

    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    
    # extract month and day of week from Start Time to create new columns
    df['Month'] = df['Start Time'].dt.month
    df['Day'] = df['Start Time'].dt.day_name()
    df['Hour'] = df['Start Time'].dt.hour
    


    # filter by month if applicable
    if month == 'none':
        print('No Filter For Months!!!')
    elif month != 'all':
        # use the index of the months list to get the corresponding int
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month)+1
    
        # filter by month to create the new dataframe
        df = df[df['Month'] == month]
       
   
    # filter by day of week if applicable
    if day == 'none':
        print('No Filter For Days!!!')
    elif day != 'all':
        # filter by day of week to create the new dataframe
        df = df[df['Day'] == day.title()]
    
    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nA) Calculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    most_pop_month = df['Month'].mode()[0]
    print("1. The Most Common Month: {}.".format(most_pop_month))

    # display the most common day of week
    most_pop_day = df['Day'].mode()[0]
    print("2. The Most Common Day: {}.".format(most_pop_day))


    # display the most common start hour
    most_pop_hour = df['Hour'].mode()[0]
    print("3. The Most Common Hour: {}.".format(most_pop_hour))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nB) Calculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    most_pop_Sstation = df['Start Station'].mode()[0]
    print("1. The Most Common Used Start Station: '{}'.".format(most_pop_Sstation))

    # display most commonly used end station
    most_pop_Estation = df['End Station'].mode()[0]
    print("2. The Most Common Used End Station: '{}'.".format(most_pop_Estation))


    # display most frequent combination of start station and end station trip
    most_pop_station_com = df.groupby(['Start Station'])['End Station'].value_counts().idxmax()
    print("3. The Most Common Used Station Combination: '{}' and '{}'.".format((most_pop_station_com)[0],(most_pop_station_com)[1]))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nC) Calculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    ttt = df['Trip Duration'].sum()
    print("1. The Total Travel Time For Trips: {}s (in seconds)".format(ttt))
    # display mean travel time
    mtt = df['Trip Duration'].mean()
    print("2. The Average Travel Time For Trips: {}s (in seconds)".format(mtt))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df,city):
    """Displays statistics on bikeshare users."""

    print('\nD) Calculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    users_tp_count = df.groupby(['User Type'])['User Type'].count()
    print("1. The Count of User Types: {} {}(s) and {} {}(s)".format(users_tp_count[0],users_tp_count.index[0],users_tp_count[1],users_tp_count.index[1]))

    if city != 'washington':
        # Display counts of gender
        users_tp_count = df.groupby(['Gender'])['Gender'].count()
        print("2. The Count of Genders: {} {}(s) and {} {}(s)".format(users_tp_count[0],users_tp_count.index[0],users_tp_count[1],users_tp_count.index[1]))

        # Display earliest, most recent, and most common year of birth
        birth_stats = df['Birth Year'].describe()
        oldest = birth_stats['min']
        print("3. The Earliest Year of Birth: {}".format(oldest))
        youngest = birth_stats['max']
        print("4. The Most Recent Year of Birth: {}".format(youngest))
        most_com_Byear = df['Birth Year'].mode()[0]
        print("5. The Most Common Year of Birth: {}".format(most_com_Byear))
    
    else: print('Unfortunately, no Gender or Birth data here')

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def show_rows(df):
    """
    Asks the user whether he wants to see 5 rows of data
    Returns 5 rows of data at a time
    """
    first = True
    while True:
        if first:
            check = input("Do you want to see the first 5 rows of data? Enter 'y' if you'd like to: ").lower().strip()
            if check == 'y':
                a,b = 0,5
                print(df[a:b])
                a += 5
                b += 5
                first = False
            else: 
                print()
                break
        
        else:
            check = input("Do you want to see the next 5 rows of data? Enter 'y' if you'd like to: ").lower().strip()
            if check == 'y':
                print(df[a:b])
                if b >= df.shape[0]:
                    print('end of file')
                    break
                a += 5
                b += 5
            else:  
                print()
                break
    return 'No more rows to show'

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        print(show_rows(df))

        restart = input('\nWould you like to start over. (y or n)?\n')
        if restart.lower() != 'y':
            break

main()

